package Assignopps1;

public class Address {
private String AddressLine;
private String city;
Address(String AddressLine,String city)
{
	this. AddressLine =  AddressLine;
	this.city = city;
}
void getAddressDetails()
{
	System.out.println("Address details are:" +AddressLine + city);
}
public String getAddressLine()
{
	return AddressLine;
}
	public void setAddressLine(String addressLine)
	{
		AddressLine = addressLine;
	}
	public String getcity()
	{
		return city;
	}
public void setCity(String city)
{
	city = city;
}
}
