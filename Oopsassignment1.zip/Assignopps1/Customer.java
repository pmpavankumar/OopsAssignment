package Assignopps1;

public class Customer {
private static final String Addressdetails = " 1st main road,btm,banglore";
private String CustomerName;
String ResidentialAddress;

Customer(String customerName,String ResidentialAddress)
{
	this.CustomerName = CustomerName;
	this.ResidentialAddress = ResidentialAddress;
}
public void getCustomerDetails()
{
	System.out.println("Customer "+ CustomerName);
	System.out.println("ResidentioalAddress " +Addressdetails);
}
public String getcustomerName()
{
	return CustomerName;
}
public void setcustomerName(String CustomerName)
{
	CustomerName = CustomerName;
}
public String getResidentialAddress()
{
	return ResidentialAddress;
}
public void setresidentialAddress()
{
	ResidentialAddress = ResidentialAddress;
}
}
