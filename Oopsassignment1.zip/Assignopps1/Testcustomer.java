package Assignopps1;

public class Testcustomer {

	public static void main(String[] args) {
		Customer tc = new Customer("pavan","1st main reoad banglore");
		tc.getResidentialAddress();
		tc.getCustomerDetails();
	}

}
