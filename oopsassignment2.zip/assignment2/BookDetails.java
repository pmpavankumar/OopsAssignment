package assignment2;

public class BookDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book b=new Book();
		b.setBookNo(101);
		b.setTitle("Java");
		b.setAuthor("Reddy");
		b.setPrice(500);
		System.out.println(b);

	}

}
